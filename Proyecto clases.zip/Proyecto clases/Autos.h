#pragma once
#include <fstream>
#include <string.h>
#include <string>
#include <iostream>

using namespace std;

class Autos
{
private:
	string Marca;
	string color;
	string Nro_de_placa;
	string Modelo;

public:
	Autos();
	~Autos();
	void setGuardarMarca(std::string);
	string getGuardarMarca();

	void setGuardarColor(std::string);
	string getGuardarColor();

	void setNroPlaca(std::string);
	string getNroPlaca();

	void setAmodelo(std::string);
	string getAmodelo();

};

