#include "Autos.h"
#include "jardineria.h"
#include "LimpiezaDeCanchas.h"
#include <string.h>
#include <iostream>
#include <string>
#include <stdlib.h>
#define NMAX 100

using namespace std;

struct Nodo {
    string Dplaca;
    string DMarca;
    string Dcolor;
    string Dmodelo;
    Nodo *siguiente;
};
void AgregarPila(Nodo *&pila, string n);
void SacarPila(Nodo*& pila, string &n);
void Escribir(Nodo *&pila);

int main()
{
    Nodo* pila = NULL;
    string DMarca, Dcolor, Dplaca, Dmodelo;
    int op = 0, ops = 0,d,j,h,g,q,s;
    char f;
    Autos Auto;
    jardineria jardin;
    LimpiezaDeCanchas canchita;
    do {
        cout << "Escriba el servicio que desee: " << endl;
        cout << "1.Servicio de lavado de autos" << endl;
        cout << "2.Servicio de jardineria " << endl;
        cout << "3.Servicio de limpieza de canchas " << endl;
        cout << "4.Salir" << endl;
        cin >> op;


        switch (op) {
        case 1:
            //Datos de la clase auto
            cout << "EL costo de lavado y aspirado tiene un costo de 50 bs" << endl;
            cout << "Desea registrar su auto? " << endl;
            cout << "1.Si" << endl;
            cout << "2.No" << endl;
            cin >> s;
            if (s == 1) {
                cin.ignore();
                cout << "Digite la marca de su auto: " << endl;
                getline(cin, DMarca);
                Auto.setGuardarMarca(DMarca);
                //PILA
                AgregarPila(*&pila, DMarca);

                cout << "Digite el color de su auto: " << endl;
                getline(cin, Dcolor);
                Auto.setGuardarColor(Dcolor);
                //PILA
                AgregarPila(*&pila, Dcolor);

                cout << "Digite el Numero de placa de su auto: " << endl;
                getline(cin, Dplaca);
                Auto.setNroPlaca(Dplaca);
                //PILA
                AgregarPila(*&pila, Dplaca);

                cout << "Digite el modelo de su auto: " << endl;
                getline(cin, Dmodelo);
                Auto.setAmodelo(Dmodelo);

                AgregarPila(*&pila, Dmodelo);
                Auto.~Autos();
                Escribir(*&pila);
            }
            if (s == 2) {
                
            }
            system("cls");
            break;
        case 2:
            //Datos de la clase jardineria
            cin.ignore();
            system("cls");
            do {
                cout << "Que tipo de servicio de jardineria desea?" << endl;
                cout << "1.Podar" << endl;
                cout << "2.Retoque de plantas" << endl;
                cout << "3.Retoque de arboles: " << endl;
                cout << "4.Regar plantas" << endl;
                cout << "5.volver" << endl;
                cin >> ops;
                switch (ops) {
                case 1:

                    cout << jardin.getPodar() << endl;
                    cout << endl;
                    break;
                case 2:
                    cout << jardin.getRetoqueDePlantas() << endl;
                    cout << endl;
                    break;
                case 3:
                    cout << jardin.getRetoqueDeArboles() << endl;
                    cout << endl;
                    break;
                case 4:
                    cout << jardin.getPodar() << endl;
                    cout << endl;
                    break;
                }
            } while (ops != 5);

            break;
        case 3:
            j = canchita.getLargo();
            h = canchita.getAncho();
            g = j * h;
            cout << "Si es de pasto sintetico tendria un precio de: " << g * 10 << " Bs." << endl;
            cout << "Si es de cemento tendria un precio de: " << g * 10 << "Bs." << endl;
            cout << "Si es de pasto tendria un precio de " << g * 10 << " Bs." << endl;
            cout << "Pulse una tecla para continuar..." << endl;
            cin >> f;
            break;
        }
        system("cls");
    } while (op != 4);

    cout << "Desea ver la Pila?" << endl;
    cout << "1.Si" << endl;
    cout << "2.No" <<endl;
    cin >> d;
    if (d == 1) {
        while (pila != NULL) {
                    SacarPila(pila, Dplaca);
                    if (pila != NULL) {
                        cout << Dplaca << " , ";
                    }
                    else {
                        cout << Dplaca << " . ";
                    }
                }
        if (d == 2) {
            system("pause");
        }
    }
}
void AgregarPila(Nodo *&pila, string n) {
    Nodo* nuevo_nodo = new Nodo(); // crear un espacio de memoria
    nuevo_nodo->Dplaca = n; // cargar dentro del nodo(dato)
    nuevo_nodo->siguiente = pila; // cargar el puntero pila dentro del nodo(*siguiente)
    pila = nuevo_nodo; // Asignar el nuevo Nodo de pila
    
}
void SacarPila(Nodo *&pila, string &n) {
    Nodo* aux = pila; // Asignar otro puntero con Nodo que valga pila
    n = aux->Dplaca; // asignarle a n el nodo anterior
    pila = aux->siguiente; //asignarle a pila el nodo anterior
    delete aux; // eliminar aux
    //se hizo lo que se pudo
}
void Escribir(Nodo *&pila) {
    ofstream archivo;
    Nodo *cliente = pila;
    char a;
    archivo.open("Cliente.txt", ios::out);

    if (archivo.fail()) {
        cout << "No se pudo abrir el archivo" << endl;
        exit(1);
    }
    archivo <<cliente;
    cout << "Se ha guardado correctamente" << endl;
    archivo.close();
    cout << "Escriba una tecla para volver: " << endl;
    cin >> a;
}

