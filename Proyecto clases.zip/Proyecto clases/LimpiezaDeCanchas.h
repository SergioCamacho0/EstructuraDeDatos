#pragma once

class LimpiezaDeCanchas
{
private:
	int ancho;
	int largo;

public:
	LimpiezaDeCanchas();
	~LimpiezaDeCanchas();
	int getLargo();
	int getAncho();
};
