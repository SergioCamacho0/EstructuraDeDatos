#include "LimpiezaDeCanchas.h"
#include <fstream>
#include <string.h>
#include <string>
#include <iostream>

using namespace std;

LimpiezaDeCanchas::LimpiezaDeCanchas() {}
LimpiezaDeCanchas::~LimpiezaDeCanchas() {}
int LimpiezaDeCanchas::getLargo() {
	int z;
	cout << "De cuantos m de largo es la cancha?" << endl;
	cin >> z;
	return z;
}
int LimpiezaDeCanchas::getAncho() {
	int l;
	cout << "Cuantos m de ancho es la cancha? " << endl;
	cin >> l;
	return l;
}