#pragma once
#include <fstream>
#include <string.h>
#include <string>
#include <iostream>

using namespace std;
class jardineria
{
	private:
		int Podar;
		int RecogerBasura;
		int RetoqueDeArboles;
		int RegarPlantas;

	public:
		jardineria();
		~jardineria();

		int getPodar();
		int getRecogerBasura();
		int getRetoqueDePlantas();
		int getRetoqueDeArboles();
		int getRegarPlantas();

};

