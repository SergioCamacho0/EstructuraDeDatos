#include "Autos.h"
#include <iostream>
#include <fstream>
#include <string.h>
#include <string>
#include <stdlib.h>

using namespace std;

Autos::Autos() {
	
}
Autos::~Autos() {

}
void Autos::setGuardarMarca(std::string _Marca) {
	Marca = _Marca;
}
string Autos::getGuardarMarca() {
	return Marca;
}
void Autos::setGuardarColor(std::string _color) {
	color = _color;
}
string Autos::getGuardarColor() {
	return color;
}
void Autos::setNroPlaca(std::string _Nro_de_placa) {
	Nro_de_placa = _Nro_de_placa;
}
string Autos::getNroPlaca() {
	return Nro_de_placa;
}
void Autos::setAmodelo(std::string _Modelo) {
	Modelo = _Modelo;
}
string Autos::getAmodelo() {
	return Modelo;
}
