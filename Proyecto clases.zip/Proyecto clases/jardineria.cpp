#include "jardineria.h"
#include <iostream>
#include <string.h>
#include <string>
#include <stdlib.h>
using namespace std;

jardineria::jardineria() {

}
jardineria::~jardineria() {

}
int jardineria::getPodar() {
	int m;
	cout << "De cuantos m^2 es su jardin?" << endl;
	cin >> m;

	return m * 40;

}

int jardineria::getRecogerBasura() {
	int n;
	cout << "De cuantos m^2 es su jardin?" << endl;
	cin >> n;

	return n * 40;
}


int jardineria::getRetoqueDePlantas() {
	int b;
	cout << "De cuantos m^2 es su jardin?" << endl;
	cin >> b;
	cout << "El precio seria: ";
	return b * 40;
}
int jardineria::getRetoqueDeArboles() {
	int v;
	cout << "De cuantos m^2 es su jardin?" << endl;
	cin >> v;
	cout << "El precio seria: ";
	return v * 40;
}
int jardineria::getRegarPlantas() {
	int c;
	cout << "De cuantos m^2 es su jardin?" << endl;
	cin >> c;
	cout << "El precio seria: ";
	return c * 40;
}
